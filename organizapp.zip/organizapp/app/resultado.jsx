import { View, Text, Button, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useLocalSearchParams, useRouter } from 'expo-router';

export default function ResultadoScreen() {
  //Captura os parâmetros 'nome' e 'idade' que foram passados na rota
  const { nome, idade } = useLocalSearchParams(); 
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Dados Recebidos na Tela 2:</Text>
      
      <Text style={styles.dataText}>
        Nome: {nome}
      </Text>
      
      <Text style={styles.dataText}>
        Idade: {idade} anos
      </Text>
      
      {/*Botão de Voltar usando a função 'back()' do useRouter*/}
      <View style={styles.buttonContainer}>
        <Button 
          title="Voltar para o Formulário" 
          onPress={() => router.back()} 
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#f7f7f7',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 30,
    marginTop: 20,
  },
  dataText: {
    fontSize: 18,
    marginBottom: 10,
    padding: 8,
    backgroundColor: '#e0e0e0',
    borderRadius: 5,
    width: '90%',
    textAlign: 'center',
  },
  buttonContainer: {
    marginTop: 50,
    width: '80%',
  },
});
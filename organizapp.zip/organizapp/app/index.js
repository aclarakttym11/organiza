import { View, Text, Button, Image } from "react-native";
import { router } from "expo-router";

export default function Home() {
  return (
    <View style={{ flex: 1, padding: 20, justifyContent: "center", alignItems: "center" }}>
      
      <Image
        source={require("../assets/schedule.png")}
        style={{ width: 160, height: 160, marginBottom: 20 }}
      />

      <Text style={{ fontSize: 26, fontWeight: "bold", marginBottom: 10 }}>
        Meus Horários
      </Text>

      <Text style={{ fontSize: 16, textAlign: "center", marginBottom: 30 }}>
        Organize sua rotina adicionando seus horários de estudo, trabalho e tarefas.
      </Text>

      <Button
        title="Adicionar novo horário"
        onPress={() => router.push("/adicionar")}
      />
    </View>
  );
}

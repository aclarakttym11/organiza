import { View, Text, Button } from "react-native";
import { useLocalSearchParams, router } from "expo-router";

export default function Detalhes() {
  const { atividade, horario } = useLocalSearchParams();

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center", padding: 20 }}>
      
      <Text style={{ fontSize: 26, fontWeight: "bold", marginBottom: 20 }}>
        Detalhes do Horário
      </Text>

      <Text style={{ fontSize: 18, marginBottom: 10 }}>
        Atividade: {atividade}
      </Text>

      <Text style={{ fontSize: 18, marginBottom: 20 }}>
        Horário: {horario}
      </Text>

      <Button title="Voltar" onPress={() => router.back()} />

    </View>
  );
}
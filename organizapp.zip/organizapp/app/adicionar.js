import { View, Text, TextInput, Button, useColorScheme } from "react-native";
import { useState } from "react";
import { router } from "expo-router";

export default function Adicionar() {
  const [atividade, setAtividade] = useState("");
  const [horario, setHorario] = useState("");

  return (
    <View style={{ flex: 1, padding: 20, justifyContent: "center" }}>
      
      <Text style={{ fontSize: 24, fontWeight: "bold", marginBottom: 20 }}>
        Adicionar Horário
      </Text>

      <Text style={{ marginBottom: 8 }}>Atividade</Text>
      <TextInput
        placeholder="Ex: Estudar matemática"
        value={atividade}
        onChangeText={setAtividade}
        style={{
          borderWidth: 1,
          borderColor: "#999",
          padding: 10,
          borderRadius: 8,
          marginBottom: 20
        }}
      />

      <Text style={{ marginBottom: 8 }}>Horário</Text>
      <TextInput
        placeholder="Ex: 14:00"
        value={horario}
        onChangeText={setHorario}
        style={{
          borderWidth: 1,
          borderColor: "#999",
          padding: 10,
          borderRadius: 8,
          marginBottom: 20
        }}
      />

      <Button
        title="Salvar"
        onPress={() =>
          router.push({
            pathname: "/detalhes",
            params: { atividade, horario }
          })
        }
      />

    </View>
  );
}
